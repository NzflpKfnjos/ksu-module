#!/system/bin/sh

MODDIR=${0%/*}
# KernelSU Action 会读取脚本的标准输出；合并 stderr 以便显示启动错误。
exec 2>&1
# KernelSU 的 Action 按钮即为明确的人工触发：直接执行清理。
exec "$MODDIR/bin/selective-reset.sh" --confirm
