#!/system/bin/sh

MODDIR=${0%/*}
# KernelSU Action 会读取脚本的标准输出；合并 stderr 以便显示启动错误。
exec 2>&1
# KernelSU 安装模块时不保证保留子目录脚本的执行位；通过 shell 解释执行，
# 既不依赖 bin/selective-reset.sh 的 x 权限，也能保留 Action 的输出通道。
exec /system/bin/sh "$MODDIR/bin/selective-reset.sh" --confirm
