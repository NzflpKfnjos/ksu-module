#!/system/bin/sh

MODDIR=${0%/*}
exec "$MODDIR/bin/selective-reset.sh" "$@"
