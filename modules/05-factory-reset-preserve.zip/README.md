# Maximum-safe Selective Factory Reset

本模块只保留仓库 `apks/` 中两个应用的数据：`org.frknkrc44.hma_oss`（HMA OSS）和 `me.weishu.kernelsu`（KernelSU）。

执行后会清理其他第三方已安装应用的数据、应用外部目录、OBB、媒体目录，以及共享存储中除 `/sdcard/Android` 外的文件。应用本身不会被卸载。

这不是 Recovery 级别的真正恢复出厂。模块不会格式化 `/data`，也不会删除系统设置、账号数据库、系统组件数据、系统分区或 eSIM，以避免系统运行期间清除框架目录导致无法启动。

## 配置保留应用

白名单已固定为上述两个 APK 对应的包名，不建议追加其他包名。

## 执行方式

模块安装后不会自动清理。先预览：

```sh
su -c /data/adb/modules/factory-reset-preserve/bin/selective-reset.sh --dry-run
```

确认列表无误后执行：

```sh
su -c /data/adb/modules/factory-reset-preserve/bin/selective-reset.sh --confirm
```

KernelSU Manager 的 **Action** 按钮会直接执行清理，无需创建确认文件。脚本将进度直接写到标准输出，因此会在 Action 窗口实时显示，并同步写入：

```sh
/data/adb/factory-reset-preserve/reset.log
```

可通过 root shell 随时查看：

```sh
su -c 'tail -f /data/adb/factory-reset-preserve/reset.log'
```

## 注意事项

- 默认处理用户 0；工作资料、多用户或双开空间需要单独处理。
- 共享存储清理会删除照片、下载、录音、聊天文件、文档和其他非 Android 目录内容。
- 执行前必须先运行 `--dry-run` 并确认备份已经完成。
- 系统预装应用通常不会被调用 `package clear`，以避免清除系统组件造成异常。
