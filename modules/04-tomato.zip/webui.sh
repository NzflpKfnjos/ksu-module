#!/system/bin/sh

if [ "$(id -u)" -ne 0 ] && [ -z "${TOMATO_WEBUI_TEST:-}" ]; then
  echo "please run as root"
  exit 1
fi

MODULE_ID="tomato"
case "$0" in
  /*) WEBUI_SELF="$0" ;;
  *) WEBUI_SELF="$(pwd)/$0" ;;
esac
MODDIR="${TOMATO_MODULE_DIR:-${WEBUI_SELF%/*}}"
[ -z "$MODDIR" ] && MODDIR="/data/adb/modules/$MODULE_ID"

AUTH_SCRIPT="$MODDIR/auth.sh"
KEY_FILE="$MODDIR/custom_key.conf"
CORE_SCRIPT="$MODDIR/1.sh"
SYSTEM_SH="${TOMATO_SYSTEM_SH:-/system/bin/sh}"
RUNTIME_DIR="${TOMATO_RUNTIME_DIR:-/data/adb/${MODULE_ID}_runtime}"
WORK_DIR="$RUNTIME_DIR/webui_work"
LOG_FILE="$RUNTIME_DIR/webui.log"
PID_FILE="$RUNTIME_DIR/trigger.pid"
PGID_FILE="$RUNTIME_DIR/trigger.pgid"
WEBUI_PID_FILE="$RUNTIME_DIR/webui.pid"
STARTING_FILE="$RUNTIME_DIR/webui.starting"
STATUS_FILE="$RUNTIME_DIR/webui.status"
ACTIVE_FILE="$RUNTIME_DIR/webui.active"

export PATH="/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/debug_ramdisk:/system/bin:/system/xbin:/vendor/bin:$PATH"
unset LD_PRELOAD

if [ -z "$TOMATO_WEBUI_NS" ] && [ -z "${TOMATO_WEBUI_TEST:-}" ]; then
  export TOMATO_WEBUI_NS=1
  for busybox in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox; do
    if [ -x "$busybox" ] && "$busybox" nsenter -t 1 -m ls / >/dev/null 2>&1; then
      exec "$busybox" nsenter -t 1 -m "$SYSTEM_SH" "$WEBUI_SELF" "$@"
    fi
  done
  if command -v nsenter >/dev/null 2>&1 && nsenter -t 1 -m ls / >/dev/null 2>&1; then
    exec nsenter -t 1 -m "$SYSTEM_SH" "$WEBUI_SELF" "$@"
  fi
fi

mkdir -p "$RUNTIME_DIR" "$WORK_DIR"
chmod 700 "$RUNTIME_DIR" "$WORK_DIR" 2>/dev/null
[ -f "$CORE_SCRIPT" ] && chmod 700 "$CORE_SCRIPT"
[ -f "$AUTH_SCRIPT" ] && chmod 700 "$AUTH_SCRIPT"
chmod 700 "$WEBUI_SELF" 2>/dev/null

CMD="${1:-status}"

file_size() {
  if [ ! -f "$1" ]; then
    printf '0'
    return
  fi
  size="$(wc -c < "$1" 2>/dev/null | tr -d ' \t')"
  case "$size" in
    ''|*[!0-9]*) printf '0' ;;
    *) printf '%s' "$size" ;;
  esac
}

is_running() {
  if [ -f "$PID_FILE" ]; then
    running_pid="$(cat "$PID_FILE" 2>/dev/null)"
    if is_pid "$running_pid" && kill -0 "$running_pid" 2>/dev/null; then
      return 0
    fi
    rm -f "$PID_FILE"
    rm -f "$PGID_FILE"
    rm -f "$WEBUI_PID_FILE"
  fi
  return 1
}

is_pid() {
  case "$1" in
    ''|*[!0-9]*) return 1 ;;
    *) return 0 ;;
  esac
}

is_webui_running() {
  [ -f "$WEBUI_PID_FILE" ] || return 1
  webui_pid="$(cat "$WEBUI_PID_FILE" 2>/dev/null)"
  running_pid="$(cat "$PID_FILE" 2>/dev/null)"
  is_pid "$webui_pid" || {
    rm -f "$WEBUI_PID_FILE"
    return 1
  }
  if [ "$webui_pid" = "$running_pid" ] && kill -0 "$webui_pid" 2>/dev/null; then
    return 0
  fi
  rm -f "$WEBUI_PID_FILE"
  return 1
}

clear_worker_pid() {
  worker_pid="$1"
  [ "$(cat "$PID_FILE" 2>/dev/null)" = "$worker_pid" ] && rm -f "$PID_FILE"
  [ "$(cat "$PGID_FILE" 2>/dev/null)" = "$worker_pid" ] && rm -f "$PGID_FILE"
  [ "$(cat "$WEBUI_PID_FILE" 2>/dev/null)" = "$worker_pid" ] && rm -f "$WEBUI_PID_FILE"
}

collect_process_tree() {
  target_pid="$1"
  is_pid "$target_pid" || return 1
  [ "$target_pid" = "$$" ] && return 1

  children_file="/proc/$target_pid/task/$target_pid/children"
  if [ -r "$children_file" ]; then
    for child_pid in $(cat "$children_file" 2>/dev/null); do
      collect_process_tree "$child_pid"
    done
  fi
  printf '%s\n' "$target_pid"
}

terminate_process_tree() {
  target_pid="$1"
  process_tree="$(collect_process_tree "$target_pid")"
  [ -n "$process_tree" ] || return 1

  for process_pid in $process_tree; do
    kill -TERM "$process_pid" 2>/dev/null || true
  done
  sleep 0.3
  for process_pid in $process_tree; do
    kill -KILL "$process_pid" 2>/dev/null || true
  done
  return 0
}

wait_for_start_registration() {
  waited=0
  while [ -f "$STARTING_FILE" ] && [ "$waited" -lt 50 ]; do
    sleep 0.1
    waited=$((waited + 1))
  done
}

register_worker() {
  worker_origin="$1"
  printf '%s\n' "$$" > "$PID_FILE"
  printf '%s\n' "$$" > "$PGID_FILE"
  if [ "$worker_origin" = "webui" ]; then
    printf '%s\n' "$$" > "$WEBUI_PID_FILE"
  else
    rm -f "$WEBUI_PID_FILE"
  fi
  rm -f "$STARTING_FILE"
}

stop_script_worker() {
  trap - HUP INT TERM
  log_event "任务已终止"
  write_status "idle" "" "143" "$(read_status_field AUTH_STATE)" "$(read_status_field AUTH_EXPIRE)" "" "$(read_status_field MODE)"
  clear_worker_pid "$$"
  rm -f "$ACTIVE_FILE"
  exit 143
}

log_event() {
  printf '%s\n' "[$(date '+%F %T')] $1" >> "$LOG_FILE"
}

write_status() {
  mode="$7"
  if [ -z "$mode" ]; then
    mode="$(read_status_field MODE)"
  fi
  {
    printf 'STATE=%s\n' "$1"
    printf 'PID=%s\n' "$2"
    printf 'EXIT_CODE=%s\n' "$3"
    printf 'AUTH_STATE=%s\n' "$4"
    printf 'AUTH_EXPIRE=%s\n' "$5"
    printf 'AUTH_ERROR=%s\n' "$6"
    printf 'MODE=%s\n' "$mode"
    printf 'LOG_SIZE=%s\n' "$(file_size "$LOG_FILE")"
  } > "$STATUS_FILE"
}

read_status_field() {
  [ -f "$STATUS_FILE" ] || return 0
  awk -F= -v key="$1" '$1 == key { print substr($0, index($0, "=") + 1); exit }' "$STATUS_FILE"
}

load_auth() {
  if [ ! -f "$AUTH_SCRIPT" ]; then
    AUTH_ERROR="授权配置缺失"
    AUTH_EXPIRE_DATE=""
    return 1
  fi
  . "$AUTH_SCRIPT"
  AUTH_TMP_DIR="$RUNTIME_DIR"
  return 0
}

emit_log() {
  if [ -f "$LOG_FILE" ]; then
    cat "$LOG_FILE"
  else
    printf '%s\n' "暂无日志"
  fi
}

copy_live_output() {
  inner_pid="$1"
  last_size=0
  while kill -0 "$inner_pid" 2>/dev/null; do
    if [ -f "$WORK_DIR/nohup.out" ]; then
      current_size="$(file_size "$WORK_DIR/nohup.out")"
      if [ "$current_size" -lt "$last_size" ]; then
        last_size=0
      fi
      if [ "$current_size" -gt "$last_size" ]; then
        tail -c +"$((last_size + 1))" "$WORK_DIR/nohup.out" >> "$LOG_FILE" 2>/dev/null
        cp "$WORK_DIR/nohup.out" "$WORK_DIR/script.out" 2>/dev/null
        last_size="$current_size"
      fi
    fi
    sleep 0.25
  done
  if [ -f "$WORK_DIR/nohup.out" ]; then
    cp "$WORK_DIR/nohup.out" "$WORK_DIR/script.out" 2>/dev/null
  fi
}

normalize_option() {
  case "$1" in
    2) printf '2' ;;
    *) printf '3' ;;
  esac
}

normalize_start_mode() {
  case "$1" in
    2|3) printf '%s' "$1" ;;
    *) printf '3' ;;
  esac
}

run_script_worker() {
  SCRIPT_OPTION="$(normalize_start_mode "$1")"
  SCRIPT_MODE="$SCRIPT_OPTION"
  WORKER_ORIGIN="${2:-webui}"
  register_worker "$WORKER_ORIGIN"
  trap 'stop_script_worker' HUP INT TERM
  touch "$ACTIVE_FILE"
  write_status "running" "$$" "" "checking" "" "" "$SCRIPT_MODE"
  : > "$LOG_FILE"
  rm -f "$WORK_DIR/nohup.out" "$WORK_DIR/wrapper.out" "$WORK_DIR/script.out"

  if ! load_auth; then
    log_event "授权失败: $AUTH_ERROR"
    write_status "idle" "" "1" "deny" "" "$AUTH_ERROR"
    clear_worker_pid "$$"
    rm -f "$ACTIVE_FILE"
    return 1
  fi

  auth_key="$(head -n 1 "$KEY_FILE" 2>/dev/null | tr -d '\r\n ')"
  if [ -z "$auth_key" ]; then
    AUTH_ERROR="未找到本地卡密"
    log_event "授权失败: $AUTH_ERROR"
    write_status "idle" "" "1" "deny" "" "$AUTH_ERROR"
    clear_worker_pid "$$"
    rm -f "$ACTIVE_FILE"
    return 1
  fi

  if ! auth_check "$auth_key"; then
    log_event "授权失败: $AUTH_ERROR"
    write_status "idle" "" "1" "deny" "" "$AUTH_ERROR"
    clear_worker_pid "$$"
    rm -f "$ACTIVE_FILE"
    return 1
  fi

  write_status "running" "$$" "" "allow" "$AUTH_EXPIRE_DATE" "" "$SCRIPT_MODE"

  TRIGGER_COMMAND="PATH=/system/bin:/system/xbin:/vendor/bin; export PATH; unset LD_PRELOAD; K=\$(cat \"$KEY_FILE\" 2>/dev/null); printf \"\$K\\n${SCRIPT_OPTION}\\n\" | \"$SYSTEM_SH\" \"$CORE_SCRIPT\""

  if [ ! -f "$CORE_SCRIPT" ]; then
    log_event "找不到脚本 1: $CORE_SCRIPT"
    write_status "idle" "" "1" "allow" "$AUTH_EXPIRE_DATE" "脚本 1 缺失" "$SCRIPT_MODE"
    clear_worker_pid "$$"
    rm -f "$ACTIVE_FILE"
    return 1
  fi

  cd "$WORK_DIR" || {
    log_event "无法进入工作目录"
    write_status "idle" "" "1" "allow" "$AUTH_EXPIRE_DATE" "无法进入工作目录"
    clear_worker_pid "$$"
    rm -f "$ACTIVE_FILE"
    return 1
  }
  touch "$WORK_DIR/nohup.out"

  sh -c "$TRIGGER_COMMAND" > "$WORK_DIR/wrapper.out" 2>&1 &
  inner_pid=$!
  copy_live_output "$inner_pid"
  wait "$inner_pid"
  trigger_exit=$?

  if [ -s "$WORK_DIR/wrapper.out" ]; then
    cp "$WORK_DIR/wrapper.out" "$LOG_FILE"
  elif [ -s "$WORK_DIR/script.out" ]; then
    cp "$WORK_DIR/script.out" "$LOG_FILE"
  fi

  write_status "idle" "" "$trigger_exit" "allow" "$AUTH_EXPIRE_DATE" ""
  clear_worker_pid "$$"
  rm -f "$ACTIVE_FILE"
  return "$trigger_exit"
}

cmd_info() {
  module_name="$(awk -F= '$1=="name"{print substr($0,index($0,"=")+1); exit}' "$MODDIR/module.prop" 2>/dev/null)"
  module_version="$(awk -F= '$1=="version"{print substr($0,index($0,"=")+1); exit}' "$MODDIR/module.prop" 2>/dev/null)"
  key_present=0
  [ -s "$KEY_FILE" ] && key_present=1
  if is_running; then
    if [ -f "$ACTIVE_FILE" ]; then
      state="running"
    else
      state="busy"
    fi
    pid="$(cat "$PID_FILE" 2>/dev/null)"
  else
    state="idle"
    pid=""
    rm -f "$ACTIVE_FILE"
  fi
  printf 'ID=%s\n' "$MODULE_ID"
  printf 'NAME=%s\n' "${module_name:-tomato}"
  printf 'VERSION=%s\n' "${module_version:-unknown}"
  printf 'KEY_PRESENT=%s\n' "$key_present"
  printf 'STATE=%s\n' "$state"
  printf 'PID=%s\n' "$pid"
  printf 'EXIT_CODE=%s\n' "$(read_status_field EXIT_CODE)"
  printf 'AUTH_STATE=%s\n' "$(read_status_field AUTH_STATE)"
  printf 'AUTH_EXPIRE=%s\n' "$(read_status_field AUTH_EXPIRE)"
  printf 'AUTH_ERROR=%s\n' "$(read_status_field AUTH_ERROR)"
  printf 'MODE=%s\n' "$(read_status_field MODE)"
  printf 'LOG_SIZE=%s\n' "$(file_size "$LOG_FILE")"
  if is_running; then
    printf 'CAN_STOP=1\n'
  else
    printf 'CAN_STOP=0\n'
  fi
}

cmd_status() {
  if is_running; then
    pid="$(cat "$PID_FILE" 2>/dev/null)"
    auth_state="$(read_status_field AUTH_STATE)"
    [ -z "$auth_state" ] && auth_state="checking"
    if [ "$(read_status_field STATE)" = "stopping" ]; then
      write_status "stopping" "$pid" "" "$auth_state" "$(read_status_field AUTH_EXPIRE)" "$(read_status_field AUTH_ERROR)"
    elif [ -f "$ACTIVE_FILE" ]; then
      write_status "running" "$pid" "" "$auth_state" "$(read_status_field AUTH_EXPIRE)" "$(read_status_field AUTH_ERROR)"
    else
      write_status "busy" "$pid" "" "$auth_state" "$(read_status_field AUTH_EXPIRE)" "$(read_status_field AUTH_ERROR)"
    fi
  else
    rm -f "$ACTIVE_FILE"
    write_status "idle" "" "$(read_status_field EXIT_CODE)" "$(read_status_field AUTH_STATE)" "$(read_status_field AUTH_EXPIRE)" "$(read_status_field AUTH_ERROR)"
  fi
  cat "$STATUS_FILE"
  if is_running; then
    printf 'CAN_STOP=1\n'
  else
    printf 'CAN_STOP=0\n'
  fi
}

cmd_activate() {
  activation_key="$2"
  if [ -z "$activation_key" ]; then
    printf 'AUTH_STATE=deny\nAUTH_ERROR=卡密不能为空\n'
    return 1
  fi
  if ! load_auth; then
    printf 'AUTH_STATE=deny\nAUTH_ERROR=%s\n' "$AUTH_ERROR"
    return 1
  fi
  if auth_check "$activation_key"; then
    umask 077
    printf '%s\n' "$activation_key" > "$KEY_FILE"
    chmod 600 "$KEY_FILE" 2>/dev/null
    printf 'AUTH_STATE=allow\nAUTH_EXPIRE=%s\nAUTH_ERROR=\n' "$AUTH_EXPIRE_DATE"
    return 0
  fi
  printf 'AUTH_STATE=deny\nAUTH_EXPIRE=\nAUTH_ERROR=%s\n' "$AUTH_ERROR"
  return 1
}

cmd_auth() {
  if ! load_auth; then
    printf 'AUTH_STATE=deny\n'
    printf 'AUTH_EXPIRE=\n'
    printf 'AUTH_ERROR=%s\n' "$AUTH_ERROR"
    return 1
  fi
  auth_key="$(head -n 1 "$KEY_FILE" 2>/dev/null | tr -d '\r\n ')"
  if [ -z "$auth_key" ]; then
    printf 'AUTH_STATE=deny\n'
    printf 'AUTH_EXPIRE=\n'
    printf 'AUTH_ERROR=未找到本地卡密\n'
    return 1
  fi
  if auth_check "$auth_key"; then
    printf 'AUTH_STATE=allow\n'
    printf 'AUTH_EXPIRE=%s\n' "$AUTH_EXPIRE_DATE"
    printf 'AUTH_ERROR=\n'
    return 0
  fi
  printf 'AUTH_STATE=deny\n'
  printf 'AUTH_EXPIRE=\n'
  printf 'AUTH_ERROR=%s\n' "$AUTH_ERROR"
  return 1
}

cmd_start() {
  SCRIPT_OPTION="$(normalize_start_mode "$1")"
  cmd_launch "$SCRIPT_OPTION"
  if [ "$?" -ne 0 ]; then
    printf 'STATE=failed\nERROR=后台任务启动失败\n'
    return 1
  fi
  printf 'STATE=started\n'
  printf 'PID=%s\n' "$(cat "$PID_FILE" 2>/dev/null)"
  printf 'MODE=%s\n' "$SCRIPT_OPTION"
}

start_detached_worker() {
  SCRIPT_OPTION="$1"
  setsid_bin=""
  for busybox in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox; do
    if [ -x "$busybox" ] && "$busybox" setsid true >/dev/null 2>&1; then
      setsid_bin="$busybox"
      break
    fi
  done

  if [ -n "$setsid_bin" ]; then
    "$setsid_bin" setsid "$SYSTEM_SH" "$WEBUI_SELF" worker "$SCRIPT_OPTION" webui \
      </dev/null >> "$WORK_DIR/daemon.out" 2>&1 &
  elif command -v setsid >/dev/null 2>&1; then
    setsid "$SYSTEM_SH" "$WEBUI_SELF" worker "$SCRIPT_OPTION" webui \
      </dev/null >> "$WORK_DIR/daemon.out" 2>&1 &
  else
    return 1
  fi

  launcher_pid="$!"
  if ! is_pid "$launcher_pid" || ! kill -0 "$launcher_pid" 2>/dev/null; then
    return 1
  fi
  return 0
}

cmd_launch() {
  SCRIPT_OPTION="$(normalize_start_mode "$1")"
  if is_running; then
    rm -f "$STARTING_FILE"
    return 0
  fi
  if ! start_detached_worker "$SCRIPT_OPTION"; then
    rm -f "$STARTING_FILE"
    return 1
  fi
  wait_for_start_registration
  [ ! -f "$STARTING_FILE" ]
}

cmd_stop() {
  if ! is_running; then
    rm -f "$WEBUI_PID_FILE"
    printf 'STATE=not_running\n'
    return 0
  fi

  worker_pid="$(cat "$PID_FILE" 2>/dev/null)"
  worker_pgid="$(cat "$PGID_FILE" 2>/dev/null)"
  write_status "stopping" "$worker_pid" "" "$(read_status_field AUTH_STATE)" "$(read_status_field AUTH_EXPIRE)" "" "$(read_status_field MODE)"
  if is_pid "$worker_pgid" && [ "$worker_pgid" = "$worker_pid" ]; then
    kill -TERM "-$worker_pgid" 2>/dev/null || true
    sleep 0.3
    kill -KILL "-$worker_pgid" 2>/dev/null || true
  elif ! terminate_process_tree "$worker_pid"; then
    printf 'STATE=failed\n'
    printf 'ERROR=无法终止进程\n'
    return 1
  fi
  if kill -0 "$worker_pid" 2>/dev/null; then
    if ! terminate_process_tree "$worker_pid"; then
      printf 'STATE=failed\n'
      printf 'ERROR=无法终止进程\n'
      return 1
    fi
  fi
  clear_worker_pid "$worker_pid"
  rm -f "$ACTIVE_FILE"
  write_status "idle" "" "143" "$(read_status_field AUTH_STATE)" "$(read_status_field AUTH_EXPIRE)" "" "$(read_status_field MODE)"
  printf 'STATE=stopping\n'
  printf 'PID=%s\n' "$worker_pid"
}

case "$CMD" in
  start)
    cmd_start "$2"
    ;;
  worker)
    run_script_worker "$2" "$3"
    ;;
  launch)
    cmd_launch "$2"
    ;;
  stop)
    cmd_stop
    ;;
  status)
    cmd_status
    ;;
  info)
    cmd_info
    ;;
  activate)
    cmd_activate "$@"
    ;;
  auth)
    cmd_auth
    ;;
  log)
    emit_log
    ;;
  *)
    printf '%s\n' "usage: webui.sh start [2|3]|launch [2|3]|stop|status|log|info|auth"
    exit 2
    ;;
esac
