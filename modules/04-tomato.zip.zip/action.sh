#!/system/bin/sh

if [ "$(id -u)" -ne 0 ]; then
  echo "please run as root"
  exit 1
fi

MODDIR=${0%/*}
[ -z "$MODDIR" ] && MODDIR="/data/adb/modules/tomato"
AUTH_SCRIPT="$MODDIR/auth.sh"
KEY_FILE="$MODDIR/custom_key.conf"
AUTH_RUNTIME="/data/adb/tomato_runtime"

export PATH="/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/debug_ramdisk:/system/bin:/system/xbin:/vendor/bin:$PATH"
unset LD_PRELOAD

if [ ! -f "$AUTH_SCRIPT" ]; then
  echo "授权配置缺失"
  exit 1
fi

. "$AUTH_SCRIPT"
AUTH_TMP_DIR="$AUTH_RUNTIME"
ACTION_KEY="$(head -n 1 "$KEY_FILE" 2>/dev/null | tr -d '\r\n ')"

if ! auth_check "$ACTION_KEY"; then
  echo "授权失败: $AUTH_ERROR"
  exit 1
fi

echo "授权通过，到期时间: $AUTH_EXPIRE_DATE"
exec /system/bin/sh "$MODDIR/2.sh" "$@"
