echo 0 > /proc/sys/fs/suid_dumpable
find /mnt/oplus -mindepth 1 -type f -delete
find /mnt/vendor/oplusreserve -mindepth 1 -type f -delete
echo 1000 > /proc/sys/kernel/pid_max
: &
sleep 1
echo 32768 > /proc/sys/kernel/pid_max
rmmod oplus_secure_guard_new oplus_secure_common
ksud soft-reboot