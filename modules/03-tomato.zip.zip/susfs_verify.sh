#!/system/bin/sh

susfs_probe_self() {
    probe_uid="$(id -u)"
    case "$probe_uid" in ''|*[!0-9]*) return 2 ;; esac
    if [ "$probe_uid" -lt 10000 ]; then
        printf '%s\n' "EFFECT=PENDING uid=$probe_uid (run inside an unmounted app process)"
        return 2
    fi
    probe_rules="$(sed -n '/^__RULES_BELOW__$/,$p' "$0" | sed '1d')"
    if [ -z "$probe_rules" ]; then
        printf '%s\n' 'EFFECT=PENDING (export the probe after registering rules)'
        return 2
    fi
    probe_failed=0
    printf '%s\n' "SUSFS app observation: uid=$probe_uid pid=$$"
    while IFS='|' read -r probe_kind probe_status probe_path; do
        [ "$probe_kind" = config ] && continue
        if [ "$probe_status" != REGISTERED ]; then
            printf '%s\n' "UNVERIFIED: $probe_kind $probe_path ($probe_status)"
            continue
        fi
        case "$probe_kind" in
            path)
                probe_output="$(LC_ALL=C ls -d "$probe_path" 2>&1)"
                probe_rc=$?
                if [ "$probe_rc" -eq 0 ]; then
                    printf '%s\n' "PATH_VISIBLE: $probe_path"
                    probe_failed=1
                else
                    case "$probe_output" in
                        *'No such file or directory'*) printf '%s\n' "PATH_NOT_OBSERVED: $probe_path" ;;
                        *) printf '%s\n' "UNVERIFIED: path $probe_path ($probe_output)" ;;
                    esac
                fi
                ;;
            map|umount)
                case "$probe_kind" in map) probe_file="/proc/$$/maps" ;; *) probe_file="/proc/$$/mountinfo" ;; esac
                if [ "$probe_kind" = map ]; then
                    probe_observation="$(awk -v p="$probe_path" '$6 == p { found=1 } END { print(found ? "VISIBLE" : "NOT_OBSERVED") }' "$probe_file" 2>/dev/null)"
                else
                    probe_observation="$(awk -v p="$probe_path" '$5 == p || index($5, p "/") == 1 { found=1 } END { print(found ? "VISIBLE" : "NOT_OBSERVED") }' "$probe_file" 2>/dev/null)"
                fi
                probe_rc=$?
                if [ "$probe_rc" -ne 0 ]; then
                    printf '%s\n' "UNVERIFIED: cannot read $probe_file"
                elif [ "$probe_observation" = VISIBLE ]; then
                    printf '%s\n' "VISIBLE: $probe_kind $probe_path"
                    probe_failed=1
                else
                    printf '%s\n' "NOT_OBSERVED: $probe_kind $probe_path"
                fi
                ;;
            *) printf '%s\n' "UNVERIFIED: unknown rule $probe_kind" ;;
        esac
    done <<EOF
$probe_rules
EOF
    if [ "$probe_failed" -ne 0 ]; then
        printf '%s\n' 'EFFECT=FAILED (configured items remain visible in this app process; check its KSU unmount profile)'
        return 1
    fi
    # Absence cannot distinguish SUSFS from access restrictions or unloaded mappings.
    printf '%s\n' 'EFFECT=PENDING (no configured item observed; this does not prove every rule took effect)'
    return 2
}

case "${1:---report}" in
    --report)
        report="${TOMATO_SUSFS_REPORT:-/data/adb/tomato_runtime/susfs.registration}"
        if [ ! -r "$report" ]; then
            printf '%s\n' 'REGISTRATION=UNKNOWN (no readable registration report)'
            exit 2
        fi
        cat "$report"
        if grep -Eq '\|FAILED[^|]*\|' "$report"; then
            printf '%s\n' 'REGISTRATION=FAILED'
            exit 1
        fi
        if ! grep -Eq '^(path|map|umount)\|' "$report"; then
            printf '%s\n' 'REGISTRATION=UNKNOWN (no rule results)'
            exit 2
        fi
        if grep -Eq '\|SKIPPED([^|]*)\|' "$report"; then
            printf '%s\n' 'REGISTRATION=PARTIAL (some optional rules were skipped)'
        else
            printf '%s\n' 'REGISTRATION=REGISTERED'
        fi
        printf '%s\n' 'EFFECT=PENDING (registration is not app visibility verification)'
        ;;
    --export)
        destination="${2:-}"
        [ -n "$destination" ] || exit 2
        report="${TOMATO_SUSFS_REPORT:-/data/adb/tomato_runtime/susfs.registration}"
        [ -r "$report" ] || exit 1
        probe_tmp="$(mktemp "${destination}.XXXXXX")" || exit 1
        if ! {
            sed '/^__RULES_BELOW__$/,$d' "$0"
            printf '%s\n' '__RULES_BELOW__'
            cat "$report"
        } > "$probe_tmp"; then
            rm -f "$probe_tmp"
            exit 1
        fi
        chmod 644 "$probe_tmp" && mv -f "$probe_tmp" "$destination" || { rm -f "$probe_tmp"; exit 1; }
        command -v restorecon >/dev/null 2>&1 && restorecon "$destination" 2>/dev/null
        printf '%s\n' "SUSFS app probe exported: $destination"
        ;;
    --self) susfs_probe_self; exit $? ;;
    *) printf '%s\n' 'Usage: susfs_verify.sh --report | --export DEST | --self'; exit 2 ;;
esac
exit 0
__RULES_BELOW__
