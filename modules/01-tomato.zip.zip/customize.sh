#!/system/bin/sh

# Tomato Module installation setup. Activation is completed in the WebUI.

[ -z "$MODPATH" ] && MODPATH="${0%/*}"
[ -z "$MODPATH" ] && MODPATH="/data/adb/modules/tomato"
CORE_SCRIPT="$MODPATH/1.sh"
PROP_FILE="$MODPATH/system.prop"
PROP_SOURCE_FILE="$MODPATH/system.prop.config"
PROP_ENABLED_FILE="$MODPATH/system.prop.enabled"
PROP_DISABLED_FILE="$MODPATH/system.prop.disabled"

ui_print() { echo "$1"; }

if [ -d "$MODPATH/webroot" ]; then
  chmod 755 "$MODPATH/webroot"
  chmod 644 "$MODPATH/webroot/"* 2>/dev/null
fi
chmod 755 "$MODPATH"/*.sh 2>/dev/null

# Do not expose the packaged profile until the remote license is checked.
if [ -f "$PROP_FILE" ] && [ ! -f "$PROP_SOURCE_FILE" ]; then
  cp "$PROP_FILE" "$PROP_SOURCE_FILE" 2>/dev/null || {
    ui_print "错误: 无法保存设备属性配置"
    exit 1
  }
  chmod 600 "$PROP_SOURCE_FILE" 2>/dev/null
fi
if [ -f "$PROP_FILE" ]; then
  mv "$PROP_FILE" "$PROP_DISABLED_FILE" 2>/dev/null || {
    ui_print "错误: 无法停用设备属性配置"
    exit 1
  }
  chmod 600 "$PROP_DISABLED_FILE" 2>/dev/null
fi
[ -f "$PROP_ENABLED_FILE" ] || printf '1\n' > "$PROP_ENABLED_FILE"
chmod 600 "$PROP_ENABLED_FILE" 2>/dev/null

ui_print ""
ui_print "====== 西红柿绿盾 ======"

if ! [ -f "$CORE_SCRIPT" ] || ! tail -n +48 "$CORE_SCRIPT" 2>/dev/null | gzip -t 2>/dev/null; then
  ui_print "错误: 1.sh 二进制载荷损坏，请重新下载模块包"
  exit 1
fi

ui_print "模块安装完成"
ui_print "请打开 KernelSU WebUI，首次输入卡密完成激活"
exit 0
