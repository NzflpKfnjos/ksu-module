#!/system/bin/sh

MODDIR="${0%/*}"
MODID="$(grep '^id=' "$MODDIR/module.prop" 2>/dev/null | head -n1 | cut -d= -f2)"
[ -z "$MODID" ] && MODID="tomato"
RUNTIME_DIR="/data/adb/${MODID}_runtime"

rm -rf "$RUNTIME_DIR"
